﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListOfSkills : MonoBehaviour
{
    public GameObject skill0;
    public GameObject skill1;
    public GameObject skill2;

    public static Dictionary<string, GameObject> Skills;

    private void Awake()
    {
        Skills = new Dictionary<string, GameObject>()
        {
            {"skill0", skill0 },
            {"skill1", skill1 },
            {"skill2", skill2 },
        };
    }
    
}
