﻿ using System.Collections;
using System.Collections.Generic;
//using System.Numerics;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Components:")]
    [HideInInspector] public Rigidbody2D rb;

    [Header("Horizontal movement variables:")]
    public float moveSpd;
    private float moveDir;

    [Header("Verical movement variables")]
    private bool jumpKeyPressed;
    public float jumpForce;
    [HideInInspector] public bool isGrounded;
    public Transform groundChecker;
    public float groundCheckRadius;
    public LayerMask groundLayer;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }


    void Update()
    {
        CheckSurroundings();
        moveDir = Input.GetAxisRaw("Horizontal");
        jumpKeyPressed = Input.GetKeyDown(KeyCode.Space);
    }


    private void FixedUpdate()
    {
        rb.velocity = new Vector2(moveDir * moveSpd, rb.velocity.y);
        if (isGrounded)
        {
            if (jumpKeyPressed)
            {
                rb.velocity = new Vector2(rb.velocity.x, 0);
                rb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
            }
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(groundChecker.position, groundCheckRadius);
    }



    //Custom functions:

    private void CheckSurroundings()
    {
        isGrounded = Physics2D.OverlapCircle(groundChecker.position, groundCheckRadius, groundLayer);
    }
}
