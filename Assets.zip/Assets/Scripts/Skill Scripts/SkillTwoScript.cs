﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillTwoScript : BaseSkillScript
{
    protected override void DeploySkill()
    {
        player.GetComponent<SpriteRenderer>().color = new Color(255, 0, 0);
        TimeManager.ResumeTime();
        RemoveSkillCanvas();
        Destroy(gameObject);
    }
}
