﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseSkillScript : MonoBehaviour
{
    public bool isSelected = false;
    protected int _clickedNumber = 0;
    private int _counter = 0;
    private delegate void ButtonFunc();
    private ButtonFunc buttonFunc;

    protected GameObject player;

    private void Start()
    {
        try
        {
            player = GameObject.FindGameObjectWithTag("Player");
        }
        catch
        {
            Debug.LogWarning("There is no player for skills to access yet!");
        }
    }

    //The logic behind clicking on the skill. First two functions are called by the third. Third is called by pressing the button.
    public void GetSelected()
    {
        isSelected = true;
        _clickedNumber++;
    }
    
    protected virtual void DeploySkill() { }//Virtual function, to be overriden

    public void ButtonClick()
    {
        switch (_clickedNumber)
        {
            case 0:
                buttonFunc = GetSelected;
                break;
            case 1:
                buttonFunc = DeploySkill;
                break;
            default:
                Debug.LogWarning("_clickedNumber is not at an appropriate value");
                print("_clickedNumber is not at an appropriate value");
                break;
        }
        buttonFunc();
    }

    //Chooses how to behave. Called when a skill is selected
    public void BehaveAppropriately()
    {
        if (isSelected == true)
            SelectedBehaviour();
        else if (isSelected == false)
            NotSelectedBehaviour();
    }


    //These two functions handle the movement and positioning of the skills once one of them has been selected. Both are called every frame.
    
    private void SelectedBehaviour()
    {
        while (_counter == 0)
        {
            _counter++;
            iTween.StopByName("move skill");
        }
        if (gameObject != null)
            transform.position = Input.mousePosition;
    }

    private void NotSelectedBehaviour()
    {
        if (gameObject != null)
            iTween.ScaleTo(gameObject, iTween.Hash("scale", new Vector3(0, 0, 0), "time", 1, "oncomplete", "DestroyMe", "ignoretimescale", true));
    }
    private void DestroyMe()
    {
        if(gameObject != null)
            Destroy(this.gameObject);
    }

    protected void RemoveSkillCanvas()
    {
        GetComponentInParent<DestroyCanvas>().DestroyThisCanvas();
    }

    
}
