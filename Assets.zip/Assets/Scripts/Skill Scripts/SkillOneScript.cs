﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillOneScript : BaseSkillScript
{
    protected override void DeploySkill()
    {
        player.GetComponent<SpriteRenderer>().color = new Color(255, 255, 255);
        TimeManager.ResumeTime();
        RemoveSkillCanvas();
        Destroy(gameObject);
    }
}
