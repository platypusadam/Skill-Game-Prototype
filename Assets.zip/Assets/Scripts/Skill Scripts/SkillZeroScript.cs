﻿using UnityEngine;

public class SkillZeroScript : BaseSkillScript
{
    private Rigidbody2D playerRb;

    protected override void DeploySkill()
    {
        playerRb = player.GetComponent<Rigidbody2D>();
        playerRb.velocity = new Vector2(playerRb.velocity.x, 0);
        playerRb.AddRelativeForce(Vector2.up * 10, ForceMode2D.Impulse);

        TimeManager.ResumeTime();

        if (gameObject != null)
            RemoveSkillCanvas();

        Destroy(gameObject);
    }
}
