﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillMenuManager : MonoBehaviour
{
    public GameObject skillMenuPrefab;
  
    [HideInInspector] public GameObject currentSkill0;
    [HideInInspector] public GameObject currentSkill1;
    [HideInInspector] public GameObject currentSkill2;
    private GameObject _skillMenu;


    //Singleton behaviour
    public static SkillMenuManager Instance;
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
            Destroy(gameObject);
        
    }
    //--------------------



    private void Start()
    {
        currentSkill0 = ListOfSkills.Skills["skill0"];
        currentSkill1 = ListOfSkills.Skills["skill1"];
        currentSkill2 = ListOfSkills.Skills["skill2"];
    }



    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (TimeManager.isPaused == false)
            {
                StartCoroutine(TimeManager.StopTime());

                if (_skillMenu == null)
                    _skillMenu = Instantiate(skillMenuPrefab);
            } 
        }
    }
}
