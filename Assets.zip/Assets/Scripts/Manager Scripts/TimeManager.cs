﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeManager
{
    public static bool isPaused { get; private set; }
    private static float _decreaseBy = 0.06f;

    public static void ResumeTime()
    {
        Time.timeScale = 1;
        Time.fixedDeltaTime = Time.timeScale * 0.02f;
        isPaused = false;
    }
    public static IEnumerator StopTime()
    {
        while(isPaused == false)
        {
            Time.timeScale -= _decreaseBy;
            Time.fixedDeltaTime *= 0.02f;
            if (Time.timeScale < 0.1f)
            {
                isPaused = true;
                Time.timeScale = 0;
            }
            yield return new WaitForEndOfFrame();
        }
    }
}
