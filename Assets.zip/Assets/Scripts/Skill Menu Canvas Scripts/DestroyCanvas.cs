﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyCanvas : MonoBehaviour
{
    public void DestroyThisCanvas()
    {
        Destroy(gameObject);
        //gameObject.SetActive(false);
    }
}
