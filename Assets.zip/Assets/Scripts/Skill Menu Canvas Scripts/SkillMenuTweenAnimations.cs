﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillMenuTweenAnimations : MonoBehaviour
{
    private GameObject skill0;
    private GameObject skill1;
    private GameObject skill2;
    private GameObject[] skills = new GameObject[3];

    public Transform startingPos;
    public Transform s0EndPos;
    public Transform s1EndPos;
    public Transform s2EndPos;


    private void OnEnable() // Called every time the canvas is enabled.
    {
        //Instantiate and set position of skills
        skill0 = Instantiate(SkillMenuManager.Instance.currentSkill0, transform);

        skill1 = Instantiate(SkillMenuManager.Instance.currentSkill1, transform);

        skill2 = Instantiate(SkillMenuManager.Instance.currentSkill2, transform);

        //Add each skill to the skill array
        skills[0] = skill0;
        skills[1] = skill1;
        skills[2] = skill2;

        //Set their position
        foreach (GameObject skill in skills)
            skill.transform.position = startingPos.transform.position;

        //Animate the skills
        iTween.MoveTo(skill0, iTween.Hash("name", "move skill", "position", s0EndPos, "time", 1.5, "ignoretimescale", true));
        iTween.MoveTo(skill1, iTween.Hash("name", "move skill", "position", s1EndPos, "time", 1.5, "ignoretimescale", true));
        iTween.MoveTo(skill2, iTween.Hash("name", "move skill", "position", s2EndPos, "time", 1.5, "ignoretimescale", true));
    }

}
