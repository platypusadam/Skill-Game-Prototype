﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillMenuCheckChildren : MonoBehaviour
{
    void Update()
    {
        foreach (Transform child in transform)
        {
            if (child.GetComponent<BaseSkillScript>() && child != null)
            {
                if (child.GetComponent<BaseSkillScript>().isSelected == true && child != null)
                {
                    foreach (Transform Child in transform)
                    {
                        if (Child.GetComponent<BaseSkillScript>() && Child != null && child != null)
                        {
                            try
                            {
                                Child.GetComponent<BaseSkillScript>().BehaveAppropriately();
                            }
                            catch
                            {
                                Debug.LogWarning("Trying to access a deleted skill, but it doesn't really matter, at least not as far as I'm aware of.");
                            }
                        }
                    }
                }
            }
        }
    }
}
